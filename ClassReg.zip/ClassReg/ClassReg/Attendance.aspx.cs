﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Core;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Configuration;
using System.Collections.Specialized;


namespace ClassReg
{
    public partial class Attendance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            PreLoader(sender, e);
        }

        protected void btnSubmit(object sender, EventArgs e)
        {
            //Add new student
            string myPath = @"C:\Users\Octavia Kay\source\repos\ClassReg"; 
            FileInfo fi = new FileInfo(myPath);
            

            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook workbook = excel.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel.Worksheet sheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;
           
            sheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets.get_Item(1);

            //Create the subject column
            sheet.Cells[1, 1] = "Class Name";
            sheet.Cells[1, 2] = "Grade";
            sheet.Cells[1, 3] = "Date Time";
            sheet.Cells[1, 4] = "Student Name";

            int _lastRow = sheet.Range["A" + sheet.Rows.Count].End[Microsoft.Office.Interop.Excel.XlDirection.xlUp].Row + 1;

            //Gets selected items from the frontend
            sheet.Cells[_lastRow, 1] = DDLClass.SelectedValue.ToString();
            sheet.Cells[_lastRow, 2] = DDLGrade.SelectedValue.ToString();
            sheet.Cells[_lastRow, 3] = DateTimeLoad.Text;
            sheet.Cells[_lastRow, 4] = TBStudentsName.Text;
            
            workbook.SaveAs(fi);
            excel.Quit();

            //Clears and reset form for new student
            TBStudentsName.Text = "";
            
            Response.Write("<script LANGUAGE='JavaScript' > alert('New Student Saved!')</script>");
        }

        protected void reset(object sender, EventArgs e)
        {
            //Fetches excel data and stores it on the front end
            string myPath = @"C:\Users\Octavia Kay\source\repos\ClassReg\ClassReg.xlsx";
            FileInfo fi = new FileInfo(myPath);

            if (fi.Exists)
            {
                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Workbook xlsWorkbook = xlApp.Workbooks.Open(@"C:\Users\Octavia Kay\source\repos\ClassReg\ClassReg.xlsx");

                _Worksheet xlsWorksheets = xlsWorkbook.Sheets[1];

                Range xlRange = xlsWorksheets.UsedRange;

                int totalRows = xlRange.Rows.Count;
                int totalColumns = xlRange.Columns.Count;

                string firstValue, secondValue, ThirdVal, FourthVal;
                
                firstValue = null;
                int i =1;

                do
                {
                    //Loop through the excel sheet till theres no data
                    List<string> ListNumbers = new List<string>();

                    ListNumbers.Add(firstValue = Convert.ToString((xlRange.Cells[i, 1] as Microsoft.Office.Interop.Excel.Range).Text));
                    ListNumbers.Add(secondValue = Convert.ToString((xlRange.Cells[i, 2] as Microsoft.Office.Interop.Excel.Range).Text));
                    ListNumbers.Add(ThirdVal = Convert.ToString((xlRange.Cells[i, 3] as Microsoft.Office.Interop.Excel.Range).Text));
                    ListNumbers.Add(FourthVal = Convert.ToString((xlRange.Cells[i, 4] as Microsoft.Office.Interop.Excel.Range).Text));

                    lblName.Text = lblName.Text + firstValue.ToString();
                    lblGrade.Text = lblGrade.Text + secondValue.ToString();
                    lblDateTime.Text = lblDateTime.Text + ThirdVal.ToString();
                    lblClass.Text = lblClass.Text + FourthVal.ToString();
                    i++;
                }//not the best way but works coz of time
                while (firstValue != "");

                xlsWorkbook.Close();
                xlApp.Quit();

                Marshal.ReleaseComObject(xlsWorksheets);
                Marshal.ReleaseComObject(xlsWorkbook);
                Marshal.ReleaseComObject(xlApp);
            }
            else
            {
               
               
            }
        }

        protected void regSave(object sender, EventArgs e)
        {
            //Gets daily report in excell
            Response.AppendHeader("content-disposition", "attachment;filename=ClassReg.xls");
            Response.Charset = "";
            
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = "application/vnd.ms-excel";
            this.EnableViewState = false;

            Response.Write(ExpTable.ToString());
            Response.End();

            Response.Write("<script LANGUAGE='JavaScript' > alert('Saved!')</script>");
        }


        protected void PreLoader(object sender, EventArgs e)
        {
            //Preload items on page-load
            //Preload all Teachers
            List<string> DDLlist = new List<string>();
            DDLlist.Add("Mrs Kunene");
            DDLlist.Add("Mrs Jones");
            DDLlist.Add("Mr Khumalo");
            DDLlist.Add("Mr Naidoo");
            DDLlist.Add("Mrs Mophias");
            DDLlist.Add("Mr Neo");
            DDLClass.DataSource = DDLlist;
            DDLClass.DataBind();

            //Preload Grade since theres only 5
            List<string> DDLlistGrade = new List<string>();
            DDLlistGrade.Add("Grade 8");
            DDLlistGrade.Add("Grade 9");
            DDLlistGrade.Add("Grade 10");
            DDLlistGrade.Add("Grade 11");
            DDLlistGrade.Add("Grade 12");
            DDLGrade.DataSource = DDLlistGrade;
            DDLGrade.DataBind();
           
            //Preload Status
            List<string> DDLlistStatusT = new List<string>();
            DDLlistStatusT.Add("Present");
            DDLlistStatusT.Add("Absent");
            DDLStatustwo.DataSource = DDLlistStatusT;
            DDLStatustwo.DataBind();
            
            //Preload Datetime
            DateTimeLoad.Text = DateTime.Now.ToString();
        }
    }
}